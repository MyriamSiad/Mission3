# Mission3
 PROJET APPLI-CR

Problème Rencontrer dans ce Projets :

On peut Offrir plusieurs médicament, qui peuvent être différents, comment faire ? 
-Ajouter un NumberUpAndDown et demander à l'utilisateur de donner le nombre de médicament différents offert 
- Puis multiplier le nombre de GrpBox composé de ComboBox Medicament et Quantité, par le nombre de sorte de médicament offert

  
--Problème resolu par un Data Grid 
